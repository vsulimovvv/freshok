<?php sect('from-center'); ?>
<h1>Slider with connect from the center</h1>

<section>

    <div class="view">

        <p><a href="https://github.com/leongersen/noUiSlider/issues/371">Issue #371</a> requested a slider with the connect option originating from the slider center.</p>

        <p>An example of how to implement this is <a href="https://jsfiddle.net/leongersen/9hyfv0bw/11/">available as a JSFiddle</a>.</p>

    </div>

    <div class="side">
    </div>
</section>
